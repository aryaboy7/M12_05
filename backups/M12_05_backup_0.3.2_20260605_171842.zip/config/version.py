APP_NAME = "M12 OS"
VERSION = "0.3.2"

UPDATE_INFO_URL = "https://raw.githubusercontent.com/aryaboy7/M12_05/main/update.json"

def version_text():
    return f"{APP_NAME} {VERSION}"