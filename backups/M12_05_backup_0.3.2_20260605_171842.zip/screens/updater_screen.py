from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button

from utils.updater import Updater
from config.version import VERSION


class UpdaterScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.updater = Updater()
        self.latest_info = None
        self.downloaded_zip = None

        root = BoxLayout(orientation="vertical", padding=20, spacing=12)

        title = Label(
            text="Updater",
            font_size=34,
            size_hint=(1, 0.15)
        )
        root.add_widget(title)

        self.status = Label(
            text=f"Current version: {VERSION}",
            font_size=22,
            size_hint=(1, 0.35)
        )
        root.add_widget(self.status)

        check_btn = Button(
            text="Check Update",
            font_size=24,
            size_hint=(1, 0.12)
        )
        check_btn.bind(on_release=self.check_update)
        root.add_widget(check_btn)

        download_btn = Button(
            text="Download Update",
            font_size=24,
            size_hint=(1, 0.12)
        )
        download_btn.bind(on_release=self.download_update)
        root.add_widget(download_btn)

        self.install_btn = Button(
            text="Install Update",
            font_size=24,
            size_hint=(1, 0.12),
            disabled=True
        )
        self.install_btn.bind(on_release=self.install_update)
        root.add_widget(self.install_btn)

        back_btn = Button(
            text="< Back",
            font_size=24,
            size_hint=(1, 0.12)
        )
        back_btn.bind(on_release=self.go_back)
        root.add_widget(back_btn)

        self.add_widget(root)

    def check_update(self, instance):
        self.status.text = "Checking update..."
        info = self.updater.check()
        self.latest_info = info

        if info.get("error"):
            self.status.text = "Update check failed:\n" + info.get("error")
            return

        if info.get("update_available"):
            self.status.text = (
                "Update available!\n\n"
                f"Current: {info.get('local_version')}\n"
                f"New: {info.get('version')}\n\n"
                f"{info.get('notes', '')}"
            )
        else:
            self.status.text = (
                "No update available.\n\n"
                f"Current: {info.get('local_version')}\n"
                f"Remote: {info.get('version')}"
            )

    def download_update(self, instance):
        if not self.latest_info:
            self.status.text = "Please check update first."
            return

        file_url = self.latest_info.get("file_url")

        if not file_url:
            self.status.text = (
                "No file_url in update.json\n\n"
                f"{self.latest_info}"
            )
            return

        self.status.text = "Downloading update..."

        result = self.updater.download(file_url)

        if result.get("ok"):
            self.downloaded_zip = result.get("path")
            self.status.text = (
                "Download complete:\n"
                f"{self.downloaded_zip}"
            )
            self.install_btn.disabled = False
        else:
            self.status.text = (
                "Download failed:\n"
                + result.get("error", "Unknown error")
            )

    def install_update(self, instance):
        self.status.text = "Installing update..."

        result = self.updater.install_zip(self.downloaded_zip)

        if result.get("ok"):
            self.status.text = (
                "Update installed.\n\n"
                f"Backup:\n{result.get('backup')}\n\n"
                "Restart M12 OS now."
            )
        else:
            self.status.text = (
                "Install failed:\n"
                + result.get("error", "Unknown error")
            )

    def go_back(self, instance):
        if self.manager:
            self.manager.current = "home"